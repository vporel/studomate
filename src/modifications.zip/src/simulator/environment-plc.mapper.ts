import { invertRecord } from "@/lib/object";
import PLCVariable, { PLCVariableScope } from "./core/plc/plc-variable";
import EnvVariable, { EnvVariableDirection } from "./interpreter/environment/env-variable";

const directionToScope: Record<EnvVariableDirection, PLCVariableScope> = {
	IN: "input",
	OUT: "output",
	INOUT: "memory",
};

const scopeToDirection = invertRecord(directionToScope);

/**
 * Traduit entre l'**environnement** du compilateur et les variables du **PLC**.
 * Voir aussi `SchemaVariablesMapper`, qui couvre l'amont de la chaîne (schéma → environnement).
 */
export default class PlcVariablesMapper {
	static envToPlc(envVar: EnvVariable): PLCVariable {
		const scope = directionToScope[envVar.getDirection()];
		const plcVar = new PLCVariable(envVar.getId(), envVar.getName(), scope, envVar.getType());
		plcVar.setValue(envVar.getValue());
		return plcVar;
	}

	static plcToEnv(plcVar: PLCVariable): EnvVariable {
		const direction = scopeToDirection[plcVar.getScope()];
		const envVar = new EnvVariable(plcVar.getId(), plcVar.getName(), plcVar.getType(), direction);
		envVar.setValue(plcVar.getValue());
		return envVar;
	}
}
