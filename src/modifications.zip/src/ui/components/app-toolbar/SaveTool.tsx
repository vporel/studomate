"use client";

import { SaveOutlined as SaveIcon, SaveAs as SaveAsIcon } from "@mui/icons-material";
import { useProjectStore } from "../projects/ProjectContext";
import AppTool from "./AppTool";

const SaveTool = () => {
	const hasUnsavedChanges = useProjectStore((state) => state.hasUnsavedChanges);
	const isSharedProject = useProjectStore((state) => state.isSharedProject);
	const saveProject = useProjectStore((state) => state.saveProject);

	if (isSharedProject) {
		return (
			<AppTool name="save-as" label="Enregistrer une copie" onClick={() => void saveProject()}>
				<SaveAsIcon />
			</AppTool>
		);
	}

	return (
		<AppTool name="save" label="Enregistrer" disabled={!hasUnsavedChanges} onClick={() => void saveProject()}>
			<SaveIcon />
		</AppTool>
	);
};

export default SaveTool;
