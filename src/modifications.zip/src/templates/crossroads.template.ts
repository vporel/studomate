import GrafcetBuilder from "@/schemas/grafcet/builders/grafcet.builder";
import StepBuilder from "@/schemas/grafcet/builders/step.builder";
import TransitionBuilder from "@/schemas/grafcet/builders/transition.builder";
import ActionBuilder from "@/schemas/grafcet/builders/action.builder";
import ConnectionBuilder from "@/schemas/grafcet/builders/connection.builder";
import { ActionExecutionMode, ActionType, ACTION_HANDLE_TARGET_STEP } from "@/schemas/grafcet/action.schema";
import { STEP_HANDLE_SOURCE_SUCCESSOR, STEP_HANDLE_TARGET_PREDECESSOR, STEP_HANDLE_SOURCE_ACTION } from "@/schemas/grafcet/step.schema";
import { TRANSITION_HANDLE_TARGET_PREDECESSOR, TRANSITION_HANDLE_SOURCE_SUCCESSOR } from "@/schemas/grafcet/transition.schema";
import { DEFAULT_GRAFCET_FORMAT } from "@/schemas/grafcet/grafcet.schema";
import HmiPage from "@/schemas/hmi/hmi-page.schema";
import { HmiWidget, IndicatorData } from "@/schemas/hmi/hmi-widget.schema";
import Project from "@/schemas/project/project.schema";
import VariableBuilder from "@/schemas/variable/builders/variable.builder";
import { createRandomId } from "@/ids";

const VOYANT_SIZE = { width: 50, height: 50 };
const VOYANT_GAP = 12;
const FEU_PADDING = 12;
const FEU_WIDTH = VOYANT_SIZE.width + 2 * FEU_PADDING;
const FEU_HEIGHT = 3 * VOYANT_SIZE.height + 2 * VOYANT_GAP + 2 * FEU_PADDING;

/** Centre du canvas */
const CX = 500;
const CY = 320;

/** Côté du rectangle de carrefour au centre */
const CROSSING_SIZE = 120;

/** Distance du centre du carrefour au centre d'un feu */
const FEU_OFFSET = CROSSING_SIZE / 2 + 20 + FEU_HEIGHT / 2;

type FeuConfig = {
	/** Mnémonique de base, ex. "NS1" → variables rougeNS1, orangeNS1, vertNS1 */
	key: string;
	label: string;
	/** Centre du feu sur le canvas */
	cx: number;
	cy: number;
};

const FEUX: FeuConfig[] = [
	{ key: "NS1", label: "Nord",  cx: CX,              cy: CY - FEU_OFFSET },
	{ key: "NS2", label: "Sud",   cx: CX,              cy: CY + FEU_OFFSET },
	{ key: "EO1", label: "Est",   cx: CX + FEU_OFFSET, cy: CY },
	{ key: "EO2", label: "Ouest", cx: CX - FEU_OFFSET, cy: CY },
];

/** Construit les données d'un voyant avec animation de style selon un mnémonique de variable. */
function indicatorData(mnemonic: string, colorOn: string, colorOff: string): IndicatorData {
	return {
		variableMnemonic: mnemonic,
		label: "",
		animations: {
			style: {
				variableMnemonic: mnemonic,
				rows: [
					{ value: 0, properties: { fill: colorOff, stroke: colorOff } },
					{ value: 1, properties: { fill: colorOn,  stroke: colorOn  } },
				],
			},
		},
	};
}

/**
 * Crée un projet "Carrefour de feux tricolores" pré-configuré :
 * — 12 variables de sortie booléennes (rouge/orange/vert × 4 feux : NS1, NS2, EO1, EO2)
 * — 1 page HMI avec 4 feux disposés autour d'un carrefour central
 * — aucun programme (l'étudiant l'écrit)
 */
export function createCrossroadsProject(): Project {
	const project = new Project(createRandomId(), "Carrefour de feux tricolores", "");

	// — Variables de sortie ———————————————————————————————————————————————
	for (const { key } of FEUX) {
		project.variables.push(
			VariableBuilder.buildLogicOutput(createRandomId(), `rouge${key}`),
			VariableBuilder.buildLogicOutput(createRandomId(), `orange${key}`),
			VariableBuilder.buildLogicOutput(createRandomId(), `vert${key}`),
		);
	}

	// — Page HMI ——————————————————————————————————————————————————————————
	const page = new HmiPage(createRandomId(), "Carrefour", true);
	let stack = 0;

	// Rectangle de chaussée central
	page.addWidget(HmiWidget.create(
		"rectangle",
		CX - CROSSING_SIZE / 2, CY - CROSSING_SIZE / 2,
		{ width: CROSSING_SIZE, height: CROSSING_SIZE },
		{ style: { fill: "#888888", stroke: "#666666", strokeWidth: 1, borderRadius: 0 } },
		stack++,
		"Chaussée",
	));

	// Titre
	page.addWidget(HmiWidget.create(
		"text",
		CX - 130, 16,
		{ width: 260, height: 28 },
		{ text: "Carrefour de feux tricolores", style: { fontSize: 16, color: "#333333", align: "center" } },
		stack++,
		"Titre",
	));

	// 4 feux
	for (const { key, label, cx, cy } of FEUX) {
		const feuX = cx - FEU_WIDTH / 2;
		const feuY = cy - FEU_HEIGHT / 2;

		// Fond du feu
		page.addWidget(HmiWidget.create(
			"rectangle",
			feuX, feuY,
			{ width: FEU_WIDTH, height: FEU_HEIGHT },
			{ style: { fill: "#1a1a1a", stroke: "#333333", strokeWidth: 2, borderRadius: 8 } },
			stack++,
			`Fond ${label}`,
		));

		// Étiquette
		page.addWidget(HmiWidget.create(
			"text",
			feuX, feuY - 24,
			{ width: FEU_WIDTH, height: 20 },
			{ text: label, style: { fontSize: 12, color: "#555555", align: "center" } },
			stack++,
			`Étiquette ${label}`,
		));

		// Voyants rouge / orange / vert
		const colors: Array<{ suffix: string; colorOn: string; colorOff: string }> = [
			{ suffix: "rouge",  colorOn: "#ff2020", colorOff: "#4a1010" },
			{ suffix: "orange", colorOn: "#ff9900", colorOff: "#4a3010" },
			{ suffix: "vert",   colorOn: "#20dd20", colorOff: "#0a3010" },
		];

		colors.forEach(({ suffix, colorOn, colorOff }, i) => {
			const vx = cx - VOYANT_SIZE.width / 2;
			const vy = feuY + FEU_PADDING + i * (VOYANT_SIZE.height + VOYANT_GAP);
			const mnemonic = `${suffix}${key}`;
			page.addWidget(HmiWidget.create(
				"indicator",
				vx, vy,
				VOYANT_SIZE,
				indicatorData(mnemonic, colorOn, colorOff),
				stack++,
				`${suffix} ${label}`,
			));
		});
	}

	project.hmiPages[page.id] = page;

	return project;
}

/**
 * Version complète et simulable du carrefour de feux tricolores.
 *
 * Séquence à 4 phases :
 *   E0 (initial) → E1 : NS vert + EO rouge (30 s)
 *               → E2 : NS orange + EO rouge (5 s)
 *               → E3 : NS rouge + EO vert (30 s)
 *               → E4 : NS rouge + EO orange (5 s)
 *               → retour E1
 */
export function createCrossroadsSolution(): Project {
	const project = createCrossroadsProject();
	project.name = "Carrefour de feux tricolores — solution";

	// Identifiants des éléments GRAFCET
	const ids = {
		e0: createRandomId(), e1: createRandomId(), e2: createRandomId(),
		e3: createRandomId(), e4: createRandomId(),
		t0: createRandomId(), t1: createRandomId(), t2: createRandomId(),
		t3: createRandomId(), t4: createRandomId(),
	};

	const X = 200;
	const e0 = new StepBuilder().id(ids.e0).number(0).initial().position(X, 60).build();
	const t0 = new TransitionBuilder().id(ids.t0).expression("1").position(X, 160).build();
	const e1 = new StepBuilder().id(ids.e1).number(1).position(X, 260).build();
	const t1 = new TransitionBuilder().id(ids.t1).expression("t1/X1/30s").position(X, 360).build();
	const e2 = new StepBuilder().id(ids.e2).number(2).position(X, 460).build();
	const t2 = new TransitionBuilder().id(ids.t2).expression("t1/X2/5s").position(X, 560).build();
	const e3 = new StepBuilder().id(ids.e3).number(3).position(X, 660).build();
	const t3 = new TransitionBuilder().id(ids.t3).expression("t1/X3/30s").position(X, 760).build();
	const e4 = new StepBuilder().id(ids.e4).number(4).position(X, 860).build();
	const t4 = new TransitionBuilder().id(ids.t4).expression("t1/X4/5s").position(X, 960).build();

	// Actions : une action booléenne continue par variable activée dans chaque phase
	type ActionSpec = { id: string; mnemonic: string; stepEl: ReturnType<StepBuilder["build"]>; ay: number };
	const actionSpecs: ActionSpec[] = [
		// Phase 1 : NS vert, EO rouge
		{ id: createRandomId(), mnemonic: "vertNS1",   stepEl: e1, ay: 260 },
		{ id: createRandomId(), mnemonic: "vertNS2",   stepEl: e1, ay: 300 },
		{ id: createRandomId(), mnemonic: "rougeEO1",  stepEl: e1, ay: 340 },
		{ id: createRandomId(), mnemonic: "rougeEO2",  stepEl: e1, ay: 380 },
		// Phase 2 : NS orange, EO rouge
		{ id: createRandomId(), mnemonic: "orangeNS1", stepEl: e2, ay: 460 },
		{ id: createRandomId(), mnemonic: "orangeNS2", stepEl: e2, ay: 500 },
		{ id: createRandomId(), mnemonic: "rougeEO1",  stepEl: e2, ay: 540 },
		{ id: createRandomId(), mnemonic: "rougeEO2",  stepEl: e2, ay: 580 },
		// Phase 3 : NS rouge, EO vert
		{ id: createRandomId(), mnemonic: "rougeNS1",  stepEl: e3, ay: 660 },
		{ id: createRandomId(), mnemonic: "rougeNS2",  stepEl: e3, ay: 700 },
		{ id: createRandomId(), mnemonic: "vertEO1",   stepEl: e3, ay: 740 },
		{ id: createRandomId(), mnemonic: "vertEO2",   stepEl: e3, ay: 780 },
		// Phase 4 : NS rouge, EO orange
		{ id: createRandomId(), mnemonic: "rougeNS1",  stepEl: e4, ay: 860 },
		{ id: createRandomId(), mnemonic: "rougeNS2",  stepEl: e4, ay: 900 },
		{ id: createRandomId(), mnemonic: "orangeEO1", stepEl: e4, ay: 940 },
		{ id: createRandomId(), mnemonic: "orangeEO2", stepEl: e4, ay: 980 },
	];

	const actions = actionSpecs.map((s) =>
		new ActionBuilder()
			.id(s.id).expression(s.mnemonic)
			.type(ActionType.BOOLEAN_VARIABLE)
			.executionMode(ActionExecutionMode.CONTINUOUS)
			.position(X + 80, s.ay)
			.build(),
	);

	const builder = new GrafcetBuilder()
		.id(createRandomId())
		.name("Carrefour de feux tricolores")
		.format(DEFAULT_GRAFCET_FORMAT)
		.addSteps(e0, e1, e2, e3, e4)
		.addTransitions(t0, t1, t2, t3, t4)
		.addActions(...actions);

	// Liaisons séquentielles étapes ↔ transitions
	const seqPairs: [ReturnType<StepBuilder["build"]> | ReturnType<TransitionBuilder["build"]>, ReturnType<StepBuilder["build"]> | ReturnType<TransitionBuilder["build"]>][] = [
		[e0, t0], [t0, e1], [e1, t1], [t1, e2],
		[e2, t2], [t2, e3], [e3, t3], [t3, e4],
		[e4, t4],
	];
	for (const [src, tgt] of seqPairs) {
		const srcHandle = src.type === "step" ? STEP_HANDLE_SOURCE_SUCCESSOR : TRANSITION_HANDLE_SOURCE_SUCCESSOR;
		const tgtHandle = tgt.type === "step" ? STEP_HANDLE_TARGET_PREDECESSOR : TRANSITION_HANDLE_TARGET_PREDECESSOR;
		builder.addConnection(ConnectionBuilder.betweenElements(createRandomId(), src, srcHandle, tgt, tgtHandle));
	}
	// Bouclage t4 → e1
	builder.addConnection(ConnectionBuilder.betweenElements(createRandomId(), t4, TRANSITION_HANDLE_SOURCE_SUCCESSOR, e1, STEP_HANDLE_TARGET_PREDECESSOR));

	// Liaisons étapes → actions
	for (const [i, spec] of actionSpecs.entries()) {
		builder.addConnection(ConnectionBuilder.betweenElements(createRandomId(), spec.stepEl, STEP_HANDLE_SOURCE_ACTION, actions[i], ACTION_HANDLE_TARGET_STEP));
	}

	project.addProgram(builder.build());
	return project;
}
