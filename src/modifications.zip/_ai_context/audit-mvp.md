Notes

## À faire (actions manuelles hors code)

### Supabase — dashboard
- [ ] Désactiver la confirmation email (Authentication → Settings → "Enable email confirmations" → off)
- [ ] Configurer l'URL de redirection pour la réinitialisation de mot de passe (Authentication → URL Configuration → Redirect URLs → ajouter l'URL de production)
- [ ] Appliquer la migration `supabase/migrations/003_shares.sql` (table `project_shares` + RLS partage)

### Sentry
- [ ] Créer un projet sur [sentry.io](https://sentry.io) (type : Next.js)
- [ ] Copier le DSN dans `.env.local` et dans les variables d'environnement de production : `NEXT_PUBLIC_SENTRY_DSN=https://xxx@xxx.ingest.sentry.io/xxx`
- [ ] Faire `npm install` après ajout de `@sentry/nextjs` dans `package.json`

### Déploiement
- [ ] Ajouter toutes les variables d'environnement en production (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_SENTRY_DSN`)

---

## Points ignorés (décisions prises)

| Point                                    | Raison |
| ---------------------------------------- | ------ |
| Accessibilité ARIA (éditeurs graphiques) |